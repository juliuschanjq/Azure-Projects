$(document).ready(() => {
  // Establish WebSocket connection
  const protocol = document.location.protocol.startsWith('https') ? 'wss://' : 'ws://';
  const webSocket = new WebSocket(protocol + location.host);

  class DeviceData {
      constructor(deviceId) {
          this.deviceId = deviceId;
          this.maxLen = 50;
          this.timeData = [];
          this.temperatureData = [];
          this.humidityData = [];
          this.gasMethaneData = [];
          this.gasCO2Data = [];
      }

      addData(time, temperature, humidity, gasMethane, gasCO2) {
          if (this.timeData.length >= this.maxLen) {
              this.timeData.shift();
              this.temperatureData.shift();
              this.humidityData.shift();
              this.gasMethaneData.shift();
              this.gasCO2Data.shift();
          }
          this.timeData.push(time);
          this.temperatureData.push(temperature);
          this.humidityData.push(humidity || null);
          this.gasMethaneData.push(gasMethane || null);
          this.gasCO2Data.push(gasCO2 || null);
      }
  }
 
  class TrackedDevices {
      constructor() {
          this.devices = [];
      }

      findDevice(deviceId) {
          return this.devices.find(device => device.deviceId === deviceId);
      }

      getDevicesCount() {
          return this.devices.length;
      }
  }

  const trackedDevices = new TrackedDevices();

  // Data for Temperature and Humidity Chart
  const tempHumidityChartData = {
      labels: [],
      datasets: [
          {
              fill: false,
              label: 'Temperature',
              yAxisID: 'Temperature',
              borderColor: 'rgba(255, 204, 0, 1)',
              pointBorderColor: 'rgba(255, 204, 0, 1)',
              backgroundColor: 'rgba(255, 204, 0, 0.4)',
              pointHoverBackgroundColor: 'rgba(255, 204, 0, 1)',
              pointHoverBorderColor: 'rgba(255, 204, 0, 1)',
              data: []
          },
          {
              fill: false,
              label: 'Humidity',
              yAxisID: 'Humidity',
              borderColor: 'rgba(24, 120, 240, 1)',
              pointBorderColor: 'rgba(24, 120, 240, 1)',
              backgroundColor: 'rgba(24, 120, 240, 0.4)',
              pointHoverBackgroundColor: 'rgba(24, 120, 240, 1)',
              pointHoverBorderColor: 'rgba(24, 120, 240, 1)',
              data: []
          }
      ]
  };

  // Data for Gas Chart
  const gasChartData = {
      labels: [],
      datasets: [
          {
              fill: false,
              label: 'Methane Gas Level',
              yAxisID: 'Gas',
              borderColor: 'rgba(255, 99, 132, 1)',
              pointBorderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.4)',
              pointHoverBackgroundColor: 'rgba(255, 99, 132, 1)',
              pointHoverBorderColor: 'rgba(255, 99, 132, 1)',
              data: []
          },
          {
              fill: false,
              label: 'CO2 Gas Level',
              yAxisID: 'Gas',
              borderColor: 'rgba(54, 162, 235, 1)',
              pointBorderColor: 'rgba(54, 162, 235, 1)',
              backgroundColor: 'rgba(54, 162, 235, 0.4)',
              pointHoverBackgroundColor: 'rgba(54, 162, 235, 1)',
              pointHoverBorderColor: 'rgba(54, 162, 235, 1)',
              data: []
          }
      ]
  };

  // Options for Temperature and Humidity Chart
  const tempHumidityChartOptions = {
      scales: {
          yAxes: [
              {
                  id: 'Temperature',
                  type: 'linear',
                  scaleLabel: {
                      labelString: 'Temperature (ºC)',
                      display: true,
                  },
                  position: 'left',
                  ticks: {
                      suggestedMin: 0,
                      suggestedMax: 100,
                      beginAtZero: true
                  }
              },
              {
                  id: 'Humidity',
                  type: 'linear',
                  scaleLabel: {
                      labelString: 'Humidity (%)',
                      display: true,
                  },
                  position: 'right',
                  ticks: {
                      suggestedMin: 0,
                      suggestedMax: 100,
                      beginAtZero: true
                  }
              }
          ]
      }
  };

  // Options for Gas Chart
  const gasChartOptions = {
      scales: {
          yAxes: [
              {
                  id: 'Gas',
                  type: 'linear',
                  scaleLabel: {
                      labelString: 'Gas Levels',
                      display: true,
                  },
                  position: 'left',
                  ticks: {
                      suggestedMin: 0,
                      suggestedMax: 1000,
                      beginAtZero: true
                  }
              }
          ]
      }
  };

  const tempHumidityCtx = document.getElementById('tempHumidityChart').getContext('2d');
  const gasCtx = document.getElementById('gasChart').getContext('2d');

  const tempHumidityChart = new Chart(tempHumidityCtx, {
      type: 'line',
      data: tempHumidityChartData,
      options: tempHumidityChartOptions,
  });

  const gasChart = new Chart(gasCtx, {
      type: 'line',
      data: gasChartData,
      options: gasChartOptions,
  });

  let needsAutoSelect = true;
  const deviceCount = document.getElementById('deviceCount');
  const listOfDevices = document.getElementById('listOfDevices');

  function OnSelectionChange() {
      const device = trackedDevices.findDevice(listOfDevices[listOfDevices.selectedIndex].text);
      if (device) {
          tempHumidityChartData.labels = device.timeData;
          tempHumidityChartData.datasets[0].data = device.temperatureData;
          tempHumidityChartData.datasets[1].data = device.humidityData;
          tempHumidityChart.update();
          
          gasChartData.labels = device.timeData;
          gasChartData.datasets[0].data = device.gasMethaneData;
          gasChartData.datasets[1].data = device.gasCO2Data;
          gasChart.update();
      }
  }

  listOfDevices.addEventListener('change', OnSelectionChange, false);

  webSocket.onmessage = function onMessage(message) {
      try {
          const messageData = JSON.parse(message.data);
          console.log(messageData);

          if (!messageData.MessageDate || (!messageData.IotData.temperature && !messageData.IotData.humidity)) {
              return;
          }

          const existingDeviceData = trackedDevices.findDevice(messageData.DeviceId);

          if (existingDeviceData) {
              existingDeviceData.addData(
                  messageData.MessageDate,
                  messageData.IotData.temperature,
                  messageData.IotData.humidity,
                  messageData.IotData.gasMethane,
                  messageData.IotData.gasCO2
              );
          } else {
              const newDeviceData = new DeviceData(messageData.DeviceId);
              trackedDevices.devices.push(newDeviceData);
              const numDevices = trackedDevices.getDevicesCount();
              deviceCount.innerText = numDevices === 1 ? `${numDevices} device` : `${numDevices} devices`;
              newDeviceData.addData(
                  messageData.MessageDate,
                  messageData.IotData.temperature,
                  messageData.IotData.humidity,
                  messageData.IotData.gasMethane,
                  messageData.IotData.gasCO2
              );

              const node = document.createElement('option');
              const nodeText = document.createTextNode(messageData.DeviceId);
              node.appendChild(nodeText);
              listOfDevices.appendChild(node);

              if (needsAutoSelect) {
                  needsAutoSelect = false;
                  listOfDevices.selectedIndex = 0;
                  OnSelectionChange();
              }
          }

          tempHumidityChart.update();
          gasChart.update();
      } catch (err) {
          console.error(err);
      }
  };
});
