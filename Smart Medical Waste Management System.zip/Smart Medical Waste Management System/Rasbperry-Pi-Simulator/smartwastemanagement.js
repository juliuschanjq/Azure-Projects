const wpi = require('wiring-pi');
const Client = require('azure-iot-device').Client;
const Message = require('azure-iot-device').Message;
const Protocol = require('azure-iot-device-mqtt').Mqtt;
const BME280 = require('bme280-sensor');

// Mock ultrasonic sensor for bin capacity (distance measurement)
function mockUltrasonicSensor() {
  // Simulate distance in centimeters
  const distance = generateRandomSensorData(0, 100); // Example range 0-100 cm
  // Convert to percentage of bin capacity
  const binCapacity = Math.min((distance / 100) * 100, 100); // Convert to percentage
  return binCapacity;
}

// Mock MQ-135 sensor for gas levels (air quality, e.g., CO2 and methane)
function mockMQ135Sensor() {
  // Simulate gas levels in ppm (parts per million)
  const gasCO2 = generateRandomSensorData(300, 1000); // Example CO2 range 300-1000 ppm
  const gasMethane = generateRandomSensorData(0, 50); // Example Methane range 0-50 ppm
  return { gasCO2, gasMethane };
}

// Mock Adafruit Ultimate GPS Breakout for GPS coordinates
function mockGPSBreakout() {
  const latitude = generateRandomSensorData(-90, 90); // Latitude range -90 to 90
  const longitude = generateRandomSensorData(-180, 180); // Longitude range -180 to 180
  return { latitude, longitude };
}

// Function to generate random sensor data
function generateRandomSensorData(min, max) {
  return Math.random() * (max - min) + min;
}

// BME280 sensor options
const BME280_OPTION = {
  i2cBusNo: 1, // defaults to 1
  i2cAddress: BME280.BME280_DEFAULT_I2C_ADDRESS() // defaults to 0x77
};

// Your connection string here
const connectionString = 'HostName=MedicalWasteManagement.azure-devices.net;DeviceId=Raspberry-Pi-Online-Simulator;SharedAccessKey=9MHyKBRTCI6EWLgUPhn8P3WphN9T5B6OGAIoTIW1h2w=';

const LEDPin = 4;

var sendingMessage = false;
var messageId = 0;
var client, sensor;
var blinkLEDTimeout = null;

function getMessage(cb) {
  messageId++;
  sensor.readSensorData()
    .then(function (data) {
      const hazardousLevel = generateRandomSensorData(0, 100); // 0-100%

      // Use mock functions for gas levels and bin capacity
      const { gasCO2, gasMethane } = mockMQ135Sensor(); // Simulate MQ-135 sensor data
      const binCapacity = mockUltrasonicSensor(); // Simulate ultrasonic sensor for bin capacity

      const { latitude, longitude } = mockGPSBreakout(); // Simulate Adafruit GPS Breakout

      // Generate Google Maps link
      const googleMapsLink = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;

      // Create the message content
      let messageContent = {
        messageId: messageId,
        deviceId: 'Raspberry Pi Web Client',
        temperature: data.temperature_C,
        humidity: data.humidity,
        hazardousLevel: hazardousLevel,
        gasMethane: gasMethane,
        gasCO2: gasCO2,
        binCapacity: binCapacity,
        latitude: latitude,
        longitude: longitude
      };

      // Add alert message if bin capacity is above 80%
      if (binCapacity > 80) {
        messageContent.alertMessage = `Bin located at latitude ${latitude}, longitude ${longitude} is over 80% full. View location: ${googleMapsLink}`;
      }

      // Add alert message if hazardous level is above 50%
      if (hazardousLevel > 50) {
        messageContent.alertMessage = `Hazardous level is above 50%: ${hazardousLevel}%. Immediate action required.`;
      }

      let message = new Message(JSON.stringify(messageContent));

      // Add custom properties for alerts
      if (binCapacity > 80) {
        message.properties.add('binCapacityAlert', 'true');
      } else {
        message.properties.add('binCapacityAlert', 'false');
      }

      if (hazardousLevel > 50) {
        message.properties.add('hazardousLevelAlert', 'true');
      } else {
        message.properties.add('hazardousLevelAlert', 'false');
      }

      // Send the message regardless of alerts
      cb(message);
    })
    .catch(function (err) {
      console.error('Failed to read out sensor data: ' + err);
    });
}

function sendMessage() {
  if (!sendingMessage) { return; }

  getMessage(function (message) {
    if (message) { // Send the message
      console.log('Sending message: ' + message.getData().toString('utf-8'));
      client.sendEvent(message, function (err) {
        if (err) {
          console.error('Failed to send message to Azure IoT Hub');
        } else {
          blinkLED();
          console.log('Message sent to Azure IoT Hub');
        }
      });
    }
  });
}

function onStart(request, response) {
  console.log('Try to invoke method start(' + request.payload + ')');
  sendingMessage = true;

  response.send(200, 'Successfully started sending messages to the cloud', function (err) {
    if (err) {
      console.error('[IoT hub Client] Failed sending a method response:\n' + err.message);
    }
  });
}

function onStop(request, response) {
  console.log('Try to invoke method stop(' + request.payload + ')');
  sendingMessage = false;

  response.send(200, 'Successfully stopped sending messages to the cloud', function (err) {
    if (err) {
      console.error('[IoT hub Client] Failed sending a method response:\n' + err.message);
    }
  });
}

function receiveMessageCallback(msg) {
  blinkLED();
  var message = msg.getData().toString('utf-8');
  client.complete(msg, function () {
    console.log('Received message: ' + message);
  });
}

function blinkLED() {
  // Light up LED for 500 ms
  if (blinkLEDTimeout) {
    clearTimeout(blinkLEDTimeout);
  }
  wpi.digitalWrite(LEDPin, 1);
  blinkLEDTimeout = setTimeout(function () {
    wpi.digitalWrite(LEDPin, 0);
  }, 500);
}

// Set up wiring
wpi.setup('wpi');
wpi.pinMode(LEDPin, wpi.OUTPUT);

sensor = new BME280(BME280_OPTION);
sensor.init()
  .then(function () {
    sendingMessage = true;
  })
  .catch(function (err) {
    console.error(err.message || err);
  });

// Create a client
client = Client.fromConnectionString(connectionString, Protocol);

client.open(function (err) {
  if (err) {
    console.error('[IoT hub Client] Connect error: ' + err.message);
    return;
  }

  // Set C2D and device method callback
  client.onDeviceMethod('start', onStart);
  client.onDeviceMethod('stop', onStop);
  client.on('message', receiveMessageCallback);
  setInterval(sendMessage, 2000);
});
